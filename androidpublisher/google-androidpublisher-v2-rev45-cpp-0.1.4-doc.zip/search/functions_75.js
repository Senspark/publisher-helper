var searchData=
[
  ['usercomment',['UserComment',['../classgoogle__androidpublisher__api_1_1UserComment.html#ae9996dedc4c30cdcc93b1e3281404b50',1,'google_androidpublisher_api::UserComment::UserComment(const Json::Value &amp;storage)'],['../classgoogle__androidpublisher__api_1_1UserComment.html#a6d6e94dfe38d5d2660429f28a9b7f5da',1,'google_androidpublisher_api::UserComment::UserComment(Json::Value *storage)']]]
];
