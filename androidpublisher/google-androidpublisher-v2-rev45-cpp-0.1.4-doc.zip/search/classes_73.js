var searchData=
[
  ['scopes',['SCOPES',['../classgoogle__androidpublisher__api_1_1AndroidPublisherService_1_1SCOPES.html',1,'google_androidpublisher_api::AndroidPublisherService']]],
  ['season',['Season',['../classgoogle__androidpublisher__api_1_1Season.html',1,'google_androidpublisher_api']]],
  ['subscriptiondeferralinfo',['SubscriptionDeferralInfo',['../classgoogle__androidpublisher__api_1_1SubscriptionDeferralInfo.html',1,'google_androidpublisher_api']]],
  ['subscriptionpurchase',['SubscriptionPurchase',['../classgoogle__androidpublisher__api_1_1SubscriptionPurchase.html',1,'google_androidpublisher_api']]],
  ['subscriptionpurchasesdeferrequest',['SubscriptionPurchasesDeferRequest',['../classgoogle__androidpublisher__api_1_1SubscriptionPurchasesDeferRequest.html',1,'google_androidpublisher_api']]],
  ['subscriptionpurchasesdeferresponse',['SubscriptionPurchasesDeferResponse',['../classgoogle__androidpublisher__api_1_1SubscriptionPurchasesDeferResponse.html',1,'google_androidpublisher_api']]],
  ['subscriptionsresource',['SubscriptionsResource',['../classgoogle__androidpublisher__api_1_1AndroidPublisherService_1_1PurchasesResource_1_1SubscriptionsResource.html',1,'google_androidpublisher_api::AndroidPublisherService::PurchasesResource']]]
];
