var searchData=
[
  ['voidedpurchase',['VoidedPurchase',['../classgoogle__androidpublisher__api_1_1VoidedPurchase.html',1,'google_androidpublisher_api']]],
  ['voidedpurchaseslistresponse',['VoidedPurchasesListResponse',['../classgoogle__androidpublisher__api_1_1VoidedPurchasesListResponse.html',1,'google_androidpublisher_api']]],
  ['voidedpurchasesresource',['VoidedpurchasesResource',['../classgoogle__androidpublisher__api_1_1AndroidPublisherService_1_1PurchasesResource_1_1VoidedpurchasesResource.html',1,'google_androidpublisher_api::AndroidPublisherService::PurchasesResource']]]
];
