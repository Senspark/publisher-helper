var searchData=
[
  ['google_20play_20developer_20api_20data_20objects',['Google Play Developer API Data Objects',['../group__DataObject.html',1,'']]],
  ['google_20play_20developer_20api_20service',['Google Play Developer API Service',['../group__ServiceClass.html',1,'']]],
  ['google_20play_20developer_20api_20service_20methods',['Google Play Developer API Service Methods',['../group__ServiceMethod.html',1,'']]]
];
